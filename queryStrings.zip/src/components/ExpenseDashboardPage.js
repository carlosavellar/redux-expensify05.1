import React from 'react';

const ExpenseDashboardPage = () => (
  <div>
    This is from my dashboard component!
  </div>
);

export default ExpenseDashboardPage;
